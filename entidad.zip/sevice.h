typedef struct
{
 int gravedad;
 char mensaje[65];
 int serviceId;
}Service;

typedef struct
{
    int id;
    char name[33];
    char email[65];
}User;

